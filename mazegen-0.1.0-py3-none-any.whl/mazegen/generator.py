"""Core maze generator."""

from random import Random
from .pattern_generator import PatternGenerator
from .solve import solve_grid
# ---- GLOBAL VARIABLES ----
NORTH = 1
EAST = 2
SOUTH = 4
WEST = 8
ALL_WALLS = NORTH | EAST | SOUTH | WEST
OPPOSITE = {NORTH: SOUTH, SOUTH: NORTH, EAST: WEST, WEST: EAST}
STEP = {NORTH: (0, -1), EAST: (1, 0), SOUTH: (0, 1), WEST: (-1, 0)}
DIRECTIONS = (NORTH, EAST, SOUTH, WEST)

# ---- "42" PATTERN CONSTANTS ----

MIN_MAP_HEIGHT = 7
MIN_MAP_WIDTH = 9


class MazeError(Exception):
    """Maze configuration errors."""
    pass


class MazeGenerator(PatternGenerator):
    def __init__(
        self,
        width: int,
        height: int,
        entry: tuple[int, int],
        exit: tuple[int, int],
        perfect: bool = False,
        seed: int | None = None,
    ) -> None:
        self.width = width
        self.height = height
        self.entry = entry
        self.exit = exit
        self.perfect = perfect
        self.seed = seed
        self._validate()
        self._reset()

    def _reset(self) -> None:
        """Restore the initial closed grid and seeded random state."""
        self.random = Random()
        if self.seed is not None:
            self.random.seed(self.seed)
        self.grid = [[ALL_WALLS] * self.width for _ in range(self.height)]
        self._blocked = self._compute_pattern()

    def _validate(self) -> None:
        if self.width < 2 or self.height < 2:
            raise MazeError(
                "Maze size must be at least 2x2 "
                f"(got {self.width}x{self.height})."
            )

        if self.entry == self.exit:
            raise MazeError("Entry and exit cannot be the same point.")
        self._validate_point(self.entry, "Entry")
        self._validate_point(self.exit, "Exit")

    def _validate_point(self, point: tuple[int, int], name: str) -> None:
        if not (0 <= point[0] < self.width):
            raise MazeError(
                f"{name} x-coordinate ({point[0]}) is outside the maze."
            )

        if not (0 <= point[1] < self.height):
            raise MazeError(
                f"{name} y-coordinate ({point[1]}) is outside the maze."
            )

    def _in_bounds(self, x: int, y: int) -> bool:
        return 0 <= x < self.width and 0 <= y < self.height

    def _neighbour(self, x: int, y: int, direction: int) -> tuple[int, int]:
        dx, dy = STEP[direction]
        return x + dx, y + dy

    def _open_wall(self, x: int, y: int, direction: int) -> None:
        # The new neighbor's coordinates are return
        nx, ny = self._neighbour(x, y, direction)
        if not self._in_bounds(nx, ny):
            raise MazeError("Cannot open a wall outside the maze.")
        # bitleri tersine çevir ve birleştir
        # (örn: doğu: 0010 ise döndür 1101 oldu.)
        self.grid[y][x] &= ~direction
        self.grid[ny][nx] &= ~OPPOSITE[direction]

    def _close_wall(self, x: int, y: int, direction: int) -> None:
        # Komşu kordinatlarını değişkenlerde kaydet.
        nx, ny = self._neighbour(x, y, direction)
        if not self._in_bounds(nx, ny):
            raise MazeError("Cannot go outside the map")
        # Don't change the cell value; just clear the specified direction bit.
        self.grid[y][x] |= direction
        self.grid[ny][nx] |= OPPOSITE[direction]

    def _open_cells(self) -> list[tuple[int, int]]:
        safe_zone = []
        for y in range(self.height):
            for x in range(self.width):
                if (x, y) not in self._blocked:
                    safe_zone.append((x, y))
        return safe_zone

    def _carve(self) -> None:  # DFS labirent oluşturumuz
        start = self.entry
        stack = [start]  # yolumuzu kaybetmemek için
        visited = {start}  # Gittiğimiz yerleri unutmamak için

        while stack:
            x, y = stack[-1]  # stackin en sonundan başla
            option = []  # seçenekler için
            for direction in DIRECTIONS:  # yönler içinde dönüyoruz 4 kere
                # komşu kordinatları tutuyoruz
                nx, ny = self._neighbour(x, y, direction)
                # komşular sınırlar içerisinde değilse continue ile geç
                if not self._in_bounds(nx, ny):
                    continue
                # komşulara daha önce gidilmişse veya yasaklı bölgeyse(42)
                if (nx, ny) in self._blocked or (nx, ny) in visited:
                    continue
                # hiç sıkıntı yoksa seçeneklere ekliyoruz
                option.append((direction, nx, ny))
            # Seçenek yoksa geri izleme için son hücreyi çıkar.
            if not option:
                stack.pop()
                continue
            # döngü bittikten sonra seçeneklerden random yol seçiyoruz
            direction, nx, ny = self.random.choice(option)
            # duvarı açıyoruz
            self._open_wall(x, y, direction)
            # gidilenlere eklioyruz
            visited.add((nx, ny))
            # yolumuzu kaybetmemek için stacke ekliyoruz
            stack.append((nx, ny))

    def generate(self) -> list[list[int]]:
        self._reset()
        self._carve()
        if not self.perfect:
            self._braid()
            self._ensure_minimum_loops(2)
        return self.grid

    def _cycle_rank(self) -> int:
        """Return the number of independent cycles in the passage graph."""
        cells = set(self._open_cells())
        edges = 0
        for x, y in cells:
            if (x + 1, y) in cells and not self.grid[y][x] & EAST:
                edges += 1
            if (x, y + 1) in cells and not self.grid[y][x] & SOUTH:
                edges += 1
        return edges - len(cells) + 1

    def _closed_internal_walls(
        self,
    ) -> list[tuple[int, int, int]]:
        """Return each closed wall between two normal cells once."""
        cells = set(self._open_cells())
        candidates: list[tuple[int, int, int]] = []
        for x, y in cells:
            for direction in (EAST, SOUTH):
                nx, ny = self._neighbour(x, y, direction)
                if (
                    (nx, ny) in cells
                    and self.grid[y][x] & direction
                ):
                    candidates.append((x, y, direction))
        self.random.shuffle(candidates)
        return candidates

    def _ensure_minimum_loops(self, minimum: int) -> None:
        """Open safe walls until the graph has *minimum* cycles."""
        if self._cycle_rank() >= minimum:
            return
        for x, y, direction in self._closed_internal_walls():
            if self._creates_open_area(x, y, direction):
                continue
            self._open_wall(x, y, direction)
            if self._cycle_rank() >= minimum:
                return
        raise MazeError(
            "Non-perfect mazes require at least two independent loops, "
            f"but {self.width}x{self.height} cannot provide them safely."
        )

    def _open_count(self, x: int, y: int) -> int:
        counter: int = 0
        for direction in DIRECTIONS:
            if not self.grid[y][x] & direction:
                counter += 1
        return counter

    def _is_open_area(self, x0: int, y0: int) -> bool:
        for y in range(y0, y0 + 3):
            for x in range(x0, x0 + 3):
                if not self._in_bounds(x, y):
                    return False
                if (x, y) in self._blocked:
                    return False

        for y in range(y0, y0 + 3):
            for x in range(x0, x0 + 3):
                if x < x0 + 2 and self.grid[y][x] & EAST:
                    return False
                if y < y0 + 2 and self.grid[y][x] & SOUTH:
                    return False
        return True

    def _creates_open_area(self, x: int, y: int, direction: int) -> bool:
        self._open_wall(x, y, direction)
        nx, ny = self._neighbour(x, y, direction)
        danger = False
        for cx, cy in ((x, y), (nx, ny)):
            for x0 in range(cx - 2, cx + 1):
                for y0 in range(cy - 2, cy + 1):
                    if self._is_open_area(x0, y0):
                        danger = True
        self._close_wall(x, y, direction)
        return danger

    def _braid(self) -> None:
        safe_zone = self._open_cells()

        # Atlanan hücre kalmaması için tüm işlemi 2 kez tekrarla (double pass)
        for _ in range(2):
            for x, y in safe_zone:
                if self._open_count(x, y) == 1:
                    local_directions = list(DIRECTIONS)
                    self.random.shuffle(local_directions)

                    # Karışan doğru liste üzerinden dönsün
                    for direction in local_directions:

                        # O yönde gerçekten kapalı bir duvar var mı?
                        # Eğer duvar yoksa (bit 0 ise) bu yönü atla
                        if not self.grid[y][x] & direction:
                            continue

                        nx, ny = self._neighbour(x, y, direction)
                        if self._in_bounds(nx, ny):
                            if (nx, ny) not in self._blocked:
                                if not self._creates_open_area(
                                    x, y, direction
                                ):
                                    self._open_wall(x, y, direction)
                                    break

    @staticmethod
    def coords_to_letters(path: list[tuple[int, int]]) -> str:
        """Koordinatları N, E, S, W yön harflerine dönüştür."""
        if not path:
            return ""

        letters = []
        # Her adımı bir sonrakiyle kıyaslıyoruz
        for i in range(len(path) - 1):
            x1, y1 = path[i]
            x2, y2 = path[i+1]

            if y2 < y1:
                letters.append("N")
            elif x2 > x1:
                letters.append("E")
            elif y2 > y1:
                letters.append("S")
            elif x2 < x1:
                letters.append("W")

        return "".join(letters)

    def solve(self) -> list[tuple[int, int]]:
        """Return the shortest entry-to-exit path.

        Raises:
            MazeError: The generated grid contains no such path.
        """
        path = solve_grid(self.grid, self.entry, self.exit)
        if not path:
            raise MazeError(
                f"No path exists between {self.entry} and {self.exit}."
            )
        return path
